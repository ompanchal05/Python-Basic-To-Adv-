# Print message
print("Hello, Python!")

# Variables
name = "Om"
age = 20
print("My name is", name, "and I am", age, "years old.")

# User input
your_name = input("What is your name? ")
print("Nice to meet you,", your_name)

# Simple math
num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))
print("Their sum is:", num1 + num2)
